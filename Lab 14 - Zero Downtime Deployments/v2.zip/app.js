/*  
    Solvimm ASAP - v2
    author:: `Bernardo Costa <bernardo.costa at solvimm.com>`
*/

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var os = require('os');
var uuid4 = require('uuid4');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port = process.env.PORT || 8080;

app.get('/', function(req, res) {
    res.json({
        hostname: os.hostname(),
        version: 2,
        msg: "**Solvimm ASAP - v2**",
        uuid4: uuid4(),
        now: new Date()
    });
})

app.listen(port, function() {
    console.log('Solvimm ASAP - v2 listening on port', port);
})